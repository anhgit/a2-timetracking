import {Component} from '@angular/core';

@Component({
    selector: 'my-app',
    template: `
        <home></home>
    `
})
export class AppComponent {
}
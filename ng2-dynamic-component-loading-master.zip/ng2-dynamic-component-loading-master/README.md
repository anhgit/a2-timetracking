Example of injecting components dynamically in Angular 2
--------------------------------------------------------

- Uses Angular2 RC-5 with webpack
- Uses ComponentFactoryResolver for injecting components dynamically

See this post for more info: [Injecting components dynamically in Angular 2](https://medium.com/p/3d36594d49a0)
